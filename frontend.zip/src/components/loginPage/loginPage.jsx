import React from 'react'

const loginPage = () => {
  return (
    <div>loginPage</div>
  )
}

export default loginPage