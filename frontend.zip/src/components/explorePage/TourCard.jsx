import { useNavigate } from "react-router-dom";
import { API_ENDPOINT } from "../../services/api.services";
import { button } from "../styles";


const TourCard = ({ tour }) => {
    const navigate = useNavigate();

    return (
        <div class="max-w-md bg-gray-200 rounded-lg shadow p-4 cursor-pointer">
            <a href="#">
                <img class="rounded-2xl hover:-translate-x-5 hover:-translate-y-2 transition-transform" src={API_ENDPOINT + tour?.image} alt={tour?.title}
                    style={{
                        minWidth: "100%",
                        height: "14rem",
                        objectFit: "cover"
                    }}
                />
            </a>
            <div class="p-4">
                <h5 class="mb-2 text-2xl text-primary font-bold tracking-tight text-gray-900">{tour?.title}</h5>
                <p class="mb-3 font-body font-normal text-dark line-clamp-4"
                    style={{
                        display: '-webkit-box',
                        WebkitLineClamp: '4',
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden'
                    }}>{tour?.overview}</p>
                <button type="button" className={`${button.outline} text-base w-full`}
                    onClick={() => {
                        navigate(`/tour/${tour?.id}/`)
                    }}>
                    Book now!
                </button>
            </div>
        </div>
    );
}

export default TourCard;

export const HotelCard = ({ hotel }) => {
    const navigate = useNavigate();

    return (
        <div className="max-w-md bg-gray-200 rounded-lg shadow p-4 cursor-pointer">
            <a href="#">
                <img className="rounded-2xl hover:-translate-x-5 hover:-translate-y-2 transition-transform" src={hotel.image} alt="hotel image"
                    style={{
                        minWidth: "100%",
                        height: "14rem",
                        objectFit: "cover"
                    }}
                />
            </a>
            <div className="p-4">
                <h5 className="mb-2 text-2xl text-primary font-bold tracking-tight text-gray-900">{hotel.name}</h5>
                <p className="font-body font-normal text-dark line-clamp-4"
                    style={{
                        display: '-webkit-box',
                        WebkitLineClamp: '4',
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden'
                    }}> - {hotel.relevantPoiDistance}</p>
                <p className="mb-3 font-body font-normal text-dark line-clamp-4"
                    style={{
                        display: '-webkit-box',
                        WebkitLineClamp: '4',
                        WebkitBoxOrient: 'vertical',
                        overflow: 'hidden'
                    }}> - Average Rating of {hotel.stars} out of 5</p>
                <button type="button" className={`${button.outline} text-base w-full`}>
                    {hotel.lowestPrice} ( {hotel.partnerName} )
                </button>
            </div>
        </div>
    );
}
