import React, { useEffect, useState } from "react";
import ItineraryView from "../tourPage/Itinerary";

import { button } from "../styles";
// import { Airplane } from "react-ionicons";
import { LuIndianRupee } from "react-icons/lu";
import { axiosAuthorized } from "../../services/api.services";
import { HotelCard } from "../explorePage/TourCard";
import { Airplane } from "iconsax-react";

const Flight = ({ item }) => {
    return (
        <>
            {/* Flight details */}
            <div className="px-6 py-4 w-auto rounded-xl px-3 shadow-xl bg-white border-2 border-grey mr-4">
                <div className="flex-col px-4">
                    <div className="flex flex-row items-center h-full">
                        {/* Flight icon and date */}
                        <div className="flex flex-col items-center gap-4 w-20 mr-4">
                            {/* <Airplane color="#00000" /> */}
                            <Airplane size={24} variant="Bold" style={{ rotate: "90deg" }} />
                            <span className="text-gray-500 text-sm mb-0">
                                {item.originDate}
                            </span>
                        </div>
                        {/* Flight details */}
                        <div className="flex flex-col justify-center items-center h-full mt-0">
                            <div className="h-full flex flex-row">
                                {/* Origin details */}
                                <div className="flex flex-col justify-center items-center">
                                    <p className="text-gray-500 text-2xl">
                                        {item.originTime}
                                    </p>
                                    <p className="text-black text-2xl">{item.cityOrigin}</p>
                                </div>
                                {/* Duration */}
                                <div className="flex flex-col gap-2 justify-center items-center">
                                    <p className="p-2">
                                        {`${Math.floor(item.Duration)}h ${Math.ceil((item.Duration % 1) * 60)}m`}
                                    </p>
                                </div>
                                {/* Destination details */}
                                <div className="flex flex-col mx-2 justify-center items-center">
                                    <p className="text-gray-500 text-2xl">
                                        {item.destTime}
                                    </p>
                                    <p className="text-black text-2xl">{item.cityDest}</p>
                                </div>
                            </div>
                            {/* Flight name, price, and airline */}
                            <div className="flex gap-2 flex-row items-center">
                                <h1 className="text-lg font-semibold text-gray-500">
                                    {item.flightName}
                                </h1>
                                <span className="text-lg font-semibold flex flex-row items-center">
                                    <LuIndianRupee />
                                    {item.price}
                                </span>
                                {/* <span className="text-sm text-gray-500">{item.airLineName}</span> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* Divider */}
            <div className="h-8 w-auto bg-gray-50"></div>
        </>

    );
};


export default function ItineraryPage() {

    const airData = [
        {
            date: "01.01.2024",
            flightName: "Air Serbia",
            airLineName: "Air India",
            price: 9999,
            Duration: 2.87,
            cityOrigin: "L.A",
            cityDest: "LON",
            originDate: "24th March",
            destDate: "2024-03-21",
            originTime: "23:25",
            destTime: "17:00",
        },
        {
            date: "02.01.2024",
            flightName: "Air France",
            airLineName: "Air India",
            price: 8888,
            Duration: 3.5,
            cityOrigin: "L.A",
            cityDest: "PAR",
            originDate: "25th March",
            destDate: "2024-03-22",
            originTime: "09:00",
            destTime: "14:30",
        },
        {
            date: "03.01.2024",
            flightName: "Air Canada",
            airLineName: "Air India",
            price: 7777,
            Duration: 5,
            cityOrigin: "L.A",
            cityDest: "TOR",
            originDate: "26th March",
            destDate: "2024-03-23",
            originTime: "13:00",
            destTime: "18:00",
        },
    ];

    const hotelsData = [
        {
            "name": "Lemon Tree Premier, Mumbai International Airport",
            "stars": "4",
            "relevantPoiDistance": "0.27 km from Marol Naka station",
            "coordinates": {
                "latitude": 19.1080837,
                "longitude": 72.8819964
            },
            "image": "https://content.skyscnr.com/available/1353160953/1353160953_WxH.jpg",
            "reviewScore": 4.5,
            "lowestPrice": "₹ 7,242",
            "partnerName": "Agoda",
            "partnerLogo": "https://www.skyscanner.co.in/images/websites/220x80/h_ad.png"
        }
    ]

    const [hotels, setHotels] = useState([])
    const [flights, setFlights] = useState([])

    useEffect(() => {
        (async () => {
            try {
                const res_hotels = await axiosAuthorized.get('fetchai/fetch_hotels/');
                console.log(res_hotels)
                // setHotels(res_hotels)

                // const res_flights = await axiosAuthorized.get('fetchai/fetch_flights/');
                // console.log(res_flights)
                // setFlights(res_flights)

            } catch (error) {
                console.error('Error fetching data:', error);
            }
        })();
    }, [])

    const sendItineraryToWhatsapp = async () => {
        const res = await axiosAuthorized.post('fetchai/send_itinerary_whatsapp/', {
            prompt: "I want to visit europe, we're a couple, it's also our first time visiting paris and we are travelling on a special occasion of our honeymoon, between the months of dec and jan and we would love to visit snowy regions",
            preferences: "trekking, swimming, visiting meuseum"
        })
        console.log(res)
    }

    const downloadAudioBook = async () => {
        const res = await axiosAuthorized.post('fetchai/send_itinerary_whatsapp/', {
            prompt: "I want to visit europe, we're a couple, it's also our first time visiting paris and we are travelling on a special occasion of our honeymoon, between the months of dec and jan and we would love to visit snowy regions",
            preferences: "trekking, swimming, visiting meuseum"
        })
        console.log(res)
    }

    const downloadPDF = async () => {
        const res = await axiosAuthorized.post('fetchai/send_itinerary_whatsapp/', {
            prompt: "I want to visit europe, we're a couple, it's also our first time visiting paris and we are travelling on a special occasion of our honeymoon, between the months of dec and jan and we would love to visit snowy regions",
            preferences: "trekking, swimming, visiting meuseum"
        })
        console.log(res)
    }

    return (
        <section className={`mx-24 flex justify-start items-center flex-col h-min-screen mt-[3rem] text-dark`}>
            <h1 className="font-bold text-3xl mb-2">THERE YOU GO!</h1>
            <h1 className="font-medium text-2xl mb-6">We have gathered some information based on the form you filled.</h1>

            <div className="flex flex-col items-start w-full my-4">
                <h1 className="font-bold text-xl mb-4">Best Rated Flights</h1>
                <div className="flex items-center">
                    {airData.map((plane, idx) => (
                        <Flight key={idx} item={plane} />
                    ))}
                </div>
            </div>

            <div className="flex flex-col items-start w-full my-4">
                <h1 className="font-bold text-xl mb-4">Recommended Hotels</h1>
                <div className="flex items-center">
                    {hotelsData.map((hotel, idx) => (
                        <HotelCard key={idx} hotel={hotel} />
                    ))}
                </div>
            </div>

            <h1 className="w-full mt-4 font-bold text-xl mb-4 text-left">Generated Itinerary</h1>
            <ItineraryView classes={"w-full"} itinerary={[{ "place": "Delhi – (Manali) 570 kms [10-12 hours drive]", "content": "Arrive Delhi airport train station and drive to Manali. Manali is an important hill station of northern India and is the destination of thousands of tourists every year. Its cool atmosphere provides a perfect haven for the ones afflicted by the hot Indian summers. Besides offering quite a few places for sightseeing, Manali is also famous for adventure sports like skiing, hiking, mountaineering, paragliding, rafting, trekking, kayaking, and mountain biking. En-route visit Hanogi Mata Temple. Overnight stay at hotel in Manali." }, { "place": "Manali - Rohtang Pass - Manali [Closed on Tuesday]", "content": "Today full day excursion visiting Kothi Gorge, Gulaba, Marhi, Rohtang Pass (Upto Snow Line in case Rohtang is closed due to snow fall. Come back to Manali Later in evening half day tour of Manali visiting newly constructed Buddhist Monastery. Hadimba Devi temple-It is small temple situated in the dense forest is very interesting. Hadimba is said to be the wife of Bhima from the epic of Mahabharata. Vashisht, it is an extremely picturesque little place clinging to the steep hill side. On the way up to the village you come upon the Vashisht hot baths where a natural sulphar spring is piped into a modern bath -house. Overnight sat at the hotel." }, { "place": "Manali – Chamunda – Dharamshala (260 km)", "content": "After breakfast, proceed for Dharamshala. En-route visit Chamunda Devi Temple. Check in to the hotel. Evening at leisure. Overnight stay at hotel." }, { "place": "Dharamshala – Dalhousie. (140 kms)", "content": "After breakfast visit Bhudhist Monastery, Bhagsunag Temple. Enjoy the scenic beauty of Dharamshala. Later drive to Dalhousie. Check in to the hotel. Overnight stay at the hotel." }, { "place": "Dalhousie - Khajjiar- Dalhousie", "content": "After having breakfast, visit Khajjiar (Khajjiar is closed some time in Dec-Jan due to heavy snow) the mini Switzerland, Kalatop, Satdhara and Gandhi Chowk. Evening free. Overnight stay at the hotel." }, { "place": "Dalhousie - Chandigarh", "content": "After breakfast proceed to Chandigarh. On arrival check in to the hotel. Evening free to explore the local markets. Overnight stay at the hotel." }, { "place": "Chandigarh to Delhi (250 kms)", "content": "After having breakfast, sightseeing of Chandigarh visit Rock garden. Rose Garden and Sukhna Lake and transfer to Delhi. On arrival transfer to train station/ airport for onward destination." }]} />

            <div className="flex items-center">
                <button type="submit" className={`${button.primary} text-xl mt-6`} onClick={downloadPDF}>Download as PDF</button>
                <button type="submit" className={`${button.primary} text-xl mt-6`} onClick={downloadAudioBook}>Download our Audio Book</button>
                <button type="submit" className={`${button.primary} text-xl mt-6`} onClick={sendItineraryToWhatsapp}>Send Itinerary to Whatsapp</button>
            </div>
        </section>
    )
}