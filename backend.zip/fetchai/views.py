import requests, datetime

from twilio.rest import Client
from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action

# from TourAPI import settings
from .models import ItineraryPlanner
from .constants import GPTItineraryGen
from . import serializers

class FetchAIViewSet(viewsets.ModelViewSet):
    queryset = ItineraryPlanner.objects.all()
    serializer_class = serializers.ItineraryPlannerSerializer
    
    def create(self, request, *args, **kwargs):
        print(request.data)
        
    @action(detail=False, methods=['GET'])
    def fetch_hotels(self, request):
        url = "https://skyscanner80.p.rapidapi.com/api/v1/hotels/search"

        querystring = {"entityId":"27539520","checkin":"2024-03-20","checkout":"2024-03-26","rooms":"1","adults":"1","resultsPerPage":"3","page":"1","currency":"INR","market":"IN","locale":"en-US"}

        headers = {
            "X-RapidAPI-Key": "574852c3e3mshb8c12847b9be5c5p16bb87jsnb99c5441d558",
            "X-RapidAPI-Host": "skyscanner80.p.rapidapi.com"
        }

        response = requests.get(url, headers=headers, params=querystring)

        data = response.json()

        hotels_list = []

        try:
            if data:
                for hotel in data.get("data", {}).get("results", {}).get("hotelCards", []):
                    if hotel.get("reviewsSummary", {}).get("score") and len(hotels_list) <= 3:
                        hotels_list.append({
                            "name": hotel.get("name"),
                            "stars": hotel.get("stars"),
                            "relevantPoiDistance": hotel.get("relevantPoiDistance"),
                            "coordinates": hotel.get("coordinates"),
                            "image": hotel.get("images", [])[0],
                            "reviewScore": hotel.get("reviewsSummary", {}).get("score"),
                            "lowestPrice": hotel.get("lowestPrice", {}).get("price"),
                            "partnerName": hotel.get("lowestPrice", {}).get("partnerName"),
                            "partnerLogo": hotel.get("lowestPrice", {}).get("partnerLogo"),
                        })
                        print(hotels_list)
            
                return Response(status=200, data=hotels_list)
        except Exception as e: 
            print(e)
            return Response(status=500, data=e)
    
    @action(detail=False, methods=['GET'])
    def fetch_flights(self, request):
        url = "https://skyscanner80.p.rapidapi.com/api/v1/flights/search-one-way"

        querystring = {"fromId":"eyJzIjoiTEFYQSIsImUiOiIyNzUzNjIxMSIsImgiOiIyNzUzNjIxMSJ9=","toId":"eyJzIjoiTE9ORCIsImUiOiIyNzU0NDAwOCIsImgiOiIyNzU0NDAwOCJ9","departDate":"2024-03-20","adults":"1","currency":"INR","market":"IN","locale":"en-US"}
        headers = {
            "X-RapidAPI-Key": "574852c3e3mshb8c12847b9be5c5p16bb87jsnb99c5441d558",
            "X-RapidAPI-Host": "skyscanner80.p.rapidapi.com"
        }
        response = requests.get(url, headers=headers, params=querystring)

        data = response.json()
        flights = []
        
        try:
            for itinerary in data["data"]["itineraries"][:3]:
                flight_name = itinerary["legs"][0]["segments"][0]["marketingCarrier"]["name"]
                airline_name = itinerary["legs"][0]["segments"][0]["operatingCarrier"]["name"]
                price = itinerary["price"]["formatted"]
                duration_minutes = itinerary["legs"][0]["durationInMinutes"]
                duration_hours = round(duration_minutes / 60, 2)

                # Extracting origin and destination details
                origin_city = itinerary["legs"][0]["origin"]["city"]
                destination_city = itinerary["legs"][0]["destination"]["city"]
                departure_datetime = itinerary["legs"][0]["departure"]
                arrival_datetime = itinerary["legs"][0]["arrival"]

                # Formatting dates and times
                departure_datetime_formatted = datetime.datetime.strptime(departure_datetime, "%Y-%m-%dT%H:%M:%S").strftime("%Y-%m-%d %H:%M")
                arrival_datetime_formatted = datetime.datetime.strptime(arrival_datetime, "%Y-%m-%dT%H:%M:%S").strftime("%Y-%m-%d %H:%M")

                # Adding flight details to the list
                flight_details = {
                    "flight_name": flight_name,
                    "airline_name": airline_name,
                    "price": price,
                    "duration_hours": duration_hours,
                    "origin_city": origin_city,
                    "destination_city": destination_city,
                    "departure_datetime": departure_datetime_formatted,
                    "arrival_datetime": arrival_datetime_formatted
                }
                flights.append(flight_details)
            
            # Returning the flight data as JSON response
            return Response(status=200, data=flights)

        except Exception as e:
            print(e)
            return Response(status=500, data=e)
    
    @action(detail=False, methods=['GET'])
    def download_audiobook(self, request):
        pass

    @action(detail=False, methods=['GET'])
    def download_pdf(self, request):
        pass

    @action(detail=False, methods=['POST'])
    def send_itinerary_whatsapp(self, request):
        prompt = request.data.get("prompt")
        preferences = request.data.get("preferences")
        
        print(preferences)
        
        
        account_sid = 'AC523a1d9bd79a2a3c5cc5b8932428119c'
        auth_token = 'f2ae5ef97fe7a8e0079aeaa47eabb5ea'
        client = Client(account_sid, auth_token)

        itinerary = GPTItineraryGen(prompt, preferences)

        message = client.messages.create(
            from_='whatsapp:+14155238886',
            body=itinerary,
            to='whatsapp:+918369386540'
        )

        return Response(status=200)